import { useState, useEffect } from 'react';

const STORAGE_KEYS = {
  WORDS: 'words',
  SETTINGS: 'settings',
  STUDY_CALENDAR: 'study-calendar',
  BADGES: 'badges'
};

export const useStorage = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // データを取得
  const getItem = async (key) => {
    try {
      const result = await window.storage.get(key);
      return result ? JSON.parse(result.value) : null;
    } catch (err) {
      console.error(`Failed to get ${key}:`, err);
      return null;
    }
  };

  // データを保存
  const setItem = async (key, value) => {
    try {
      await window.storage.set(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error(`Failed to set ${key}:`, err);
      setError(`データの保存に失敗しました: ${err.message}`);
      return false;
    }
  };

  // データを削除
  const removeItem = async (key) => {
    try {
      await window.storage.delete(key);
      return true;
    } catch (err) {
      console.error(`Failed to delete ${key}:`, err);
      return false;
    }
  };

  // 全データをクリア
  const clearAll = async () => {
    try {
      const keys = Object.values(STORAGE_KEYS);
      await Promise.all(keys.map(key => removeItem(key)));
      return true;
    } catch (err) {
      console.error('Failed to clear all data:', err);
      return false;
    }
  };

  return {
    isLoading,
    error,
    getItem,
    setItem,
    removeItem,
    clearAll,
    STORAGE_KEYS
  };
};

// 単語データ専用フック
export const useWords = () => {
  const [words, setWords] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const storage = useStorage();

  useEffect(() => {
    loadWords();
  }, []);

  const loadWords = async () => {
    setIsLoading(true);
    const data = await storage.getItem(storage.STORAGE_KEYS.WORDS);
    setWords(data || []);
    setIsLoading(false);
  };

  const saveWords = async (newWords) => {
    const success = await storage.setItem(storage.STORAGE_KEYS.WORDS, newWords);
    if (success) {
      setWords(newWords);
    }
    return success;
  };

  const addWord = async (word) => {
    const newWords = [...words, word];
    return await saveWords(newWords);
  };

  const updateWord = async (id, updates) => {
    const newWords = words.map(w => w.id === id ? { ...w, ...updates } : w);
    return await saveWords(newWords);
  };

  const deleteWord = async (id) => {
    const newWords = words.filter(w => w.id !== id);
    return await saveWords(newWords);
  };

  return {
    words,
    isLoading,
    addWord,
    updateWord,
    deleteWord,
    saveWords,
    reloadWords: loadWords
  };
};

// 学習カレンダー専用フック
export const useStudyCalendar = () => {
  const [calendar, setCalendar] = useState({});
  const storage = useStorage();

  useEffect(() => {
    loadCalendar();
  }, []);

  const loadCalendar = async () => {
    const data = await storage.getItem(storage.STORAGE_KEYS.STUDY_CALENDAR);
    setCalendar(data || {});
  };

  const saveCalendar = async (newCalendar) => {
    const success = await storage.setItem(storage.STORAGE_KEYS.STUDY_CALENDAR, newCalendar);
    if (success) {
      setCalendar(newCalendar);
    }
    return success;
  };

  const updateToday = async (count, correct) => {
    const today = new Date().toISOString().split('T')[0];
    const newCalendar = {
      ...calendar,
      [today]: {
        count: (calendar[today]?.count || 0) + count,
        correct: (calendar[today]?.correct || 0) + correct
      }
    };
    return await saveCalendar(newCalendar);
  };

  return {
    calendar,
    updateToday,
    saveCalendar,
    reloadCalendar: loadCalendar
  };
};

// 設定専用フック
export const useSettings = () => {
  const [settings, setSettings] = useState({
    intervals: [1, 2, 4, 7, 14, 30, 60, 90, 120, 180],
    defaultMode: 'random',
    dailyGoal: 15,
    notifications: false
  });
  const storage = useStorage();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const data = await storage.getItem(storage.STORAGE_KEYS.SETTINGS);
    if (data) {
      setSettings(data);
    }
  };

  const saveSettings = async (newSettings) => {
    const success = await storage.setItem(storage.STORAGE_KEYS.SETTINGS, newSettings);
    if (success) {
      setSettings(newSettings);
    }
    return success;
  };

  const updateSetting = async (key, value) => {
    const newSettings = { ...settings, [key]: value };
    return await saveSettings(newSettings);
  };

  return {
    settings,
    updateSetting,
    saveSettings
  };
};

// バッジ専用フック
export const useBadges = () => {
  const [unlockedBadges, setUnlockedBadges] = useState([]);
  const storage = useStorage();

  useEffect(() => {
    loadBadges();
  }, []);

  const loadBadges = async () => {
    const data = await storage.getItem(storage.STORAGE_KEYS.BADGES);
    setUnlockedBadges(data || []);
  };

  const unlockBadge = async (badgeId) => {
    if (!unlockedBadges.includes(badgeId)) {
      const newBadges = [...unlockedBadges, badgeId];
      const success = await storage.setItem(storage.STORAGE_KEYS.BADGES, newBadges);
      if (success) {
        setUnlockedBadges(newBadges);
      }
      return success;
    }
    return false;
  };

  return {
    unlockedBadges,
    unlockBadge
  };
};
