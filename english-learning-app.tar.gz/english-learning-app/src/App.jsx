import React, { useState, useEffect } from 'react';
import { Home, BookOpen, BarChart3, Settings as SettingsIcon } from 'lucide-react';

// Components (will be created)
import HomePage from './components/HomePage';
import WordListPage from './components/WordListPage';
import LearningPage from './components/LearningPage';
import StatisticsPage from './components/StatisticsPage';
import SettingsPage from './components/SettingsPage';
import AddWordModal from './components/AddWordModal';

// Hooks
import { useWords, useStudyCalendar, useSettings, useBadges } from './hooks/useStorage';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [showAddWordModal, setShowAddWordModal] = useState(false);
  const [learningMode, setLearningMode] = useState(null);
  
  const { words, isLoading, addWord, updateWord, deleteWord, saveWords } = useWords();
  const { calendar, updateToday } = useStudyCalendar();
  const { settings, updateSetting } = useSettings();
  const { unlockedBadges, unlockBadge } = useBadges();

  // 学習開始
  const startLearning = (mode) => {
    setLearningMode(mode);
    setCurrentPage('learning');
  };

  // 学習完了
  const completeLearning = async (results) => {
    const correctCount = results.filter(r => r.correct).length;
    await updateToday(results.length, correctCount);
    
    // バッジチェック（ここでは省略、StatisticsPageで実装）
    setCurrentPage('home');
  };

  // 単語追加
  const handleAddWord = async (wordData) => {
    await addWord(wordData);
    setShowAddWordModal(false);
  };

  // ローディング中
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">読み込み中...</p>
        </div>
      </div>
    );
  }

  // ページのレンダリング
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <HomePage
            words={words}
            calendar={calendar}
            settings={settings}
            onStartLearning={startLearning}
            onAddWord={() => setShowAddWordModal(true)}
            onNavigate={setCurrentPage}
          />
        );
      case 'wordlist':
        return (
          <WordListPage
            words={words}
            onUpdateWord={updateWord}
            onDeleteWord={deleteWord}
            onAddWord={() => setShowAddWordModal(true)}
          />
        );
      case 'learning':
        return (
          <LearningPage
            words={words}
            mode={learningMode}
            settings={settings}
            onComplete={completeLearning}
            onUpdateWord={updateWord}
          />
        );
      case 'statistics':
        return (
          <StatisticsPage
            words={words}
            calendar={calendar}
            unlockedBadges={unlockedBadges}
            onUnlockBadge={unlockBadge}
          />
        );
      case 'settings':
        return (
          <SettingsPage
            settings={settings}
            words={words}
            onUpdateSetting={updateSetting}
            onExport={() => {/* 実装 */}}
            onImport={() => {/* 実装 */}}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* メインコンテンツ */}
      <div className="pb-20">
        {renderPage()}
      </div>

      {/* 単語追加モーダル */}
      {showAddWordModal && (
        <AddWordModal
          onClose={() => setShowAddWordModal(false)}
          onSave={handleAddWord}
        />
      )}

      {/* ボトムナビゲーション（学習中は非表示） */}
      {currentPage !== 'learning' && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
          <div className="max-w-md mx-auto grid grid-cols-4 gap-1">
            <button
              onClick={() => setCurrentPage('home')}
              className={`flex flex-col items-center py-3 px-2 ${
                currentPage === 'home' ? 'text-indigo-600' : 'text-gray-600'
              }`}
            >
              <Home size={24} />
              <span className="text-xs mt-1">ホーム</span>
            </button>
            <button
              onClick={() => setCurrentPage('wordlist')}
              className={`flex flex-col items-center py-3 px-2 ${
                currentPage === 'wordlist' ? 'text-indigo-600' : 'text-gray-600'
              }`}
            >
              <BookOpen size={24} />
              <span className="text-xs mt-1">単語帳</span>
            </button>
            <button
              onClick={() => setCurrentPage('statistics')}
              className={`flex flex-col items-center py-3 px-2 ${
                currentPage === 'statistics' ? 'text-indigo-600' : 'text-gray-600'
              }`}
            >
              <BarChart3 size={24} />
              <span className="text-xs mt-1">統計</span>
            </button>
            <button
              onClick={() => setCurrentPage('settings')}
              className={`flex flex-col items-center py-3 px-2 ${
                currentPage === 'settings' ? 'text-indigo-600' : 'text-gray-600'
              }`}
            >
              <SettingsIcon size={24} />
              <span className="text-xs mt-1">設定</span>
            </button>
          </div>
        </nav>
      )}
    </div>
  );
}

export default App;
