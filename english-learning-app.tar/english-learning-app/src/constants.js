// フィールド文字数制限
export const FIELD_LIMITS = {
  english: 200,
  japanese: 500,
  example: 500,
  note: 2000,
  tags: 10,
  tagLength: 20
};

// ステータスの定義
export const STATUS_LEVELS = {
  MADAMADA: 'まだまだ',
  KIKERU: '聞ける',
  HANASERU: '話せる',
  KAKERU: '書ける',
  MASTER: 'マスター'
};

// カテゴリの定義
export const CATEGORIES = {
  WORD: 'word',
  IDIOM: 'idiom',
  PHRASE: 'phrase'
};

export const CATEGORY_LABELS = {
  word: '単語',
  idiom: '慣用句',
  phrase: 'フレーズ'
};

// 学習モード
export const LEARNING_MODES = {
  EN_TO_JP: 'english-to-japanese',
  JP_TO_EN: 'japanese-to-english',
  RANDOM: 'random'
};

export const LEARNING_MODE_LABELS = {
  'english-to-japanese': '英語 → 日本語',
  'japanese-to-english': '日本語 → 英語',
  'random': 'ランダム'
};

// デフォルトの復習間隔（パターンB）
export const DEFAULT_INTERVALS = [1, 2, 4, 7, 14, 30, 60, 90, 120, 180];

// バッジ定義
export const BADGES = [
  { id: 'first_step', name: '初めの一歩', description: '最初の単語を登録', unlockCondition: (stats) => stats.totalWords >= 1 },
  { id: 'collector_10', name: '単語コレクター', description: '10語登録', unlockCondition: (stats) => stats.totalWords >= 10 },
  { id: 'collector_50', name: '単語マニア', description: '50語登録', unlockCondition: (stats) => stats.totalWords >= 50 },
  { id: 'collector_100', name: '単語博士', description: '100語登録', unlockCondition: (stats) => stats.totalWords >= 100 },
  { id: 'week_warrior', name: '1週間継続', description: '7日連続学習', unlockCondition: (stats) => stats.currentStreak >= 7 },
  { id: 'month_champion', name: '1ヶ月継続', description: '30日連続学習', unlockCondition: (stats) => stats.currentStreak >= 30 },
  { id: 'accuracy_master', name: '精度マスター', description: '正答率90%以上を達成', unlockCondition: (stats) => stats.overallAccuracy >= 90 },
  { id: 'master_10', name: '10語マスター', description: '10語をマスター', unlockCondition: (stats) => stats.masterCount >= 10 },
  { id: 'master_50', name: '50語マスター', description: '50語をマスター', unlockCondition: (stats) => stats.masterCount >= 50 },
  { id: 'speedster', name: 'スピードスター', description: '平均回答時間3秒以下', unlockCondition: (stats) => stats.averageResponseTime <= 3000 }
];

// レベル計算用の経験値テーブル
export const LEVEL_XP_TABLE = [
  0, 100, 250, 450, 700, 1000, 1400, 1900, 2500, 3200,
  4000, 5000, 6200, 7600, 9200, 11000, 13000, 15200, 17600, 20200
];

// やる気スコアの重み
export const MOTIVATION_WEIGHTS = {
  streak: 30,
  recentAccuracy: 25,
  consistency: 25,
  challengeAccepted: 20
};
